package rs.ac.uns.ftn.examples.xpath.test;

import java.io.File;
import java.io.OutputStream;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathException;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * 
 * Primer demonstrira upotrebu Xpath API-ja za potrebe izvršavanja XPath 
 * upita nad elementima DOM stabla parsiranog XML dokumenta.
 * 
 * Primer izvršava kolekciju XPath upita iz "data/test/books_xpath.xml"
 * nad "data/books.xml" dokumentom i ispisuje rezultate evaluacije na
 * standardni izlaz.
 * 
 */
public class XPathExpressionTester {

	private static DocumentBuilderFactory documentFactory;
	
	private static TransformerFactory transformerFactory;
	
	private static XPathFactory xPathFactory;
	
	/*
	 * Factory initialization static-block
	 */
	static {

		/* Inicijalizacija DOM fabrike */
		documentFactory = DocumentBuilderFactory.newInstance();
		documentFactory.setNamespaceAware(true);
		documentFactory.setIgnoringComments(true);
		documentFactory.setIgnoringElementContentWhitespace(true);
		
		/* Inicijalizacija Transformer fabrike */
		transformerFactory = TransformerFactory.newInstance();
		
		/* Inicijalizacija XPath fabrike */
		xPathFactory = XPathFactory.newInstance();
		
	}
	
	public static void main(String args[]) {

		String xmlFilePath = null, xpathFilePath = null;

		Document xpathDocument, xmlDocument;
		
		System.out.println("[INFO] XPath Expression Tester");

		if (args.length != 2) {

			xmlFilePath = "data/books.xml";
			xpathFilePath = "data/test/books_xpath.xml";

			System.out.println("[INFO] No input file, using default \""	+ xmlFilePath + "\"");

		} else {
			xmlFilePath = args[0];
			xpathFilePath = args[1];
		}

		XPathExpressionTester handler = new XPathExpressionTester();

		// Kreiranje DOM stabla na osnovu XML fajlova
		xmlDocument = handler.buildDocument(xmlFilePath);
		xpathDocument = handler.buildDocument(xpathFilePath);

		//handler.transform(xmlDocument, System.out);

		// Evaluacija test XPath izraza 
		handler.test(xmlDocument, xpathDocument);

		System.out.println("\n[INFO] Kraj.");
	}
	
	/**
	 * Generates document object model for a given XML file.
	 * 
	 * @param filePath XML document file path
	 * @return document object model representstion
	 */
	public Document buildDocument(String filePath) {

		Document document = null;
		
		try {
			
			DocumentBuilder builder = documentFactory.newDocumentBuilder();
			document = builder.parse(new File(filePath)); 

			/* Detektuju eventualne greske */
			if (document != null)
				System.out.println("[INFO] File \"" + filePath + "\" parsed with no errors.");
			else
				System.out.println("[WARN] Document is null.");

		} catch (SAXParseException e) {
			
			System.out.println("[ERROR] Parsing error, line: " + e.getLineNumber() + ", uri: " + e.getSystemId());
			System.out.println("[ERROR] " + e.getMessage() );
			System.out.print("[ERROR] Embedded exception: ");
			
			Exception embeddedException = e;
			if (e.getException() != null)
				embeddedException = e.getException();

			// Print stack trace...
			embeddedException.printStackTrace();
			
			System.exit(0);
			
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return document;
	}

	/**
	 * Serializes DOM tree to an arbitrary OutputStream.
	 *
	 * @param node a node to be serialized
	 * @param out an output stream to write the serialized 
	 * DOM representation to
	 * 
	 */
	public void transform(Node node, OutputStream out) {
		try {

			// Kreiranje instance objekta zaduzenog za serijalizaciju DOM modela
			Transformer transformer = transformerFactory.newTransformer();

			// Indentacija serijalizovanog izlaza
			transformer.setOutputProperty("{http://xml.apache.org/xalan}indent-amount", "2");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");

			// Nad "source" objektom (DOM stablo) vrši se transformacija
			DOMSource source = new DOMSource(node);

			// Rezultujući stream (argument metode) 
			StreamResult result = new StreamResult(out);

			// Poziv metode koja vrši opisanu transformaciju
			transformer.transform(source, result);
			
		} catch (TransformerConfigurationException e) {
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			e.printStackTrace();
		} catch (TransformerException e) {
			e.printStackTrace();
		}
	}

	/** 
	 * Convenience method XPath expression evaluation.
	 */
	private void test(Document xmlDocument, Document xpathDocument) {
		
		// Izlistava sve "xpath" čvorove na bilo kom nivou hijerarhije
		String expression = "//xpath/expression";
		String description = "//xpath/description";
		
		NodeList expressionNodeList, descriptionNodeList, nodeList;
		Node expressionNode, descriptionNode, node;
		
		try {
			
			// Upotrebom XPath API-ja izvlačimo sve XPath izraze i njihove opise iz DOM stabla
			expressionNodeList = (NodeList) evaluateXPath(expression, xpathDocument, XPathConstants.NODESET);
			descriptionNodeList = (NodeList) evaluateXPath(description, xpathDocument, XPathConstants.NODESET);
			
			for (int i = 0; i < expressionNodeList.getLength(); i++) {
				expressionNode = expressionNodeList.item(i);
				descriptionNode = descriptionNodeList.item(i);
				
				System.out.println("\n[INFO] Description: " + descriptionNode.getTextContent());
				
				// Evaluacija pojedinačnog XPath izraza nad DOM stablom originalnog dokumenta
				nodeList = (NodeList) evaluateXPath(expressionNode.getTextContent(), xmlDocument, XPathConstants.NODESET);
				
				// Ispis rezultata izvršavanja XPath izraza
				for (int nodeIndex = 0; nodeIndex < nodeList.getLength(); nodeIndex++) {
				
					node = nodeList.item(nodeIndex);
					
					if (node.getNodeType() == Node.TEXT_NODE)
						System.out.println(node.getNodeValue());
					else
						transform(node, System.out);
				
				}
			}
			
		} catch (XPathExpressionException e) {
			System.out.println("[ERROR] Error evaluationg \"" + expression + "\" expression, line: " + e.getMessage());
		}
		
	}

	/**
	 * Evaluates the provided XPath expression.
	 * 
	 * @param expression an XPath expression to be evaluated
	 * @param document a subject of evaluation
	 * @param returnType desired return type
	 * @throws XPathException if the expression cannot be evaluated
	 */

	public Object evaluateXPath(String expression, Document document, QName returnType) throws XPathExpressionException {
		
		XPath xPath = xPathFactory.newXPath();
		XPathExpression xPathExpression = xPath.compile(expression);
			
		System.out.println("[INFO] Evaluating the expression: \"" + expression + "\"");
		
		return xPathExpression.evaluate(document, returnType);
		
	}

}
