@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ftn.uns.ac.rs/examples/xmldb/bookstore", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package rs.ac.uns.ftn.examples.xmldb.bookstore;
