package com.example.demo.domain;

public enum OS {
    LINUX,
    WINDOWS,
    BSD,
    OTHER
}
