package com.example.demo.conf;

public class EndpointConfiguration {

    public static final String SERVER_BASE_URL = "/api/server";
    public static final String SERVER_ID_ENDPOINT = "{id}";
    public static final String SERVER_ID_URL = SERVER_BASE_URL + SERVER_ID_ENDPOINT;
}
